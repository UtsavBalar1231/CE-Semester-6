package com.example.storage_access_example;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    //MediaPlayer mp = new MediaPlayer();
    MediaPlayer mp=MediaPlayer.create(getApplicationContext(),R.raw.song);
    Button start = (Button) findViewById(R.id.start);
    Button stop = (Button) findViewById(R.id.stop);
    Button pause = (Button) findViewById(R.id.pause);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT > 22) {
            requestPermissions(new String[]
                    {READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, 1);
        }
        try {
            mp.setDataSource(Environment.getExternalStorageDirectory().getPath()+"/Music/song.mp3");
            //mp.setDataSource("/storage/emulated/0/Music/song.wav");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mp.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.start();
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.pause();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                mp.reset(); // To reset your audio file, so you can again start playing your new/same audio file from step – 2.
            }
        });
    }
}