//
//  ViewController.swift
//  practical5
//
//  Created by bmiit on 07/03/22.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    @IBOutlet var prime_input: UITextField!
    
    @IBOutlet var prime_output: UILabel!
    @IBAction func check_prime(_ sender: Any) {
        if let num: Int = Int(prime_input.text!) {
            if is_prime(num: num) {
                prime_output.text = "Is a prime number"
            }
            else {
                prime_output.text = "Not a prime number"
            }
        }
    }
    
    func is_prime(num: Int) -> Bool {
        if num <= 1 {return false}
        for i in 2..<num {
            if num % i == 0 {return false}
        }
        return true
    }
    
    
    @IBOutlet var palindrome_input: UITextField!
    @IBOutlet var palindrome_output: UILabel!
    @IBAction func check_palindrome(_ sender: Any) {
        let str_t = palindrome_input.text!
        if is_palindrome(str_t: str_t) {
            palindrome_output.text = "Is a Palindrome"
        } else {
            palindrome_output.text = "Not a Palindrome"
        }
    }
    
    func is_palindrome(str_t: String) -> Bool
    {
        if str_t == String(str_t.reversed()) {return true}
        return false
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}

