trait TypeToStr {
    fn get_type_str (&self) -> &'static str;
}

macro_rules! impl_type_to_str {
    ($($T: ty),+) => {
        $(
        impl TypeToStr for $T {
            fn get_type_str (&self) -> &'static str { stringify!($T) }
        }
        )*
    }
}

impl_type_to_str!(i32, f64);

macro_rules! print_type {
    ($e: expr) => {
        println!("{}", $e.get_type_str());
    }
}

#[allow(dead_code)]
#[derive(Debug)]
pub struct Body {
    pub eyes: u8,
    pub nose: u8,
    pub hands: u8,
    pub legs: u8,
    pub mouth: u8,
}
#[allow(dead_code)]
#[derive(Debug)]
pub enum Creature {
    Dog(Body),
    Cat(Body),
    Human(Body),
    Mythical(Body),
}

impl TypeToStr for Creature {
    fn get_type_str (&self) -> &'static str {
        match self {
            Creature::Dog(_) => "Dog",
            Creature::Cat(_) => "Cat",
            Creature::Human(_) => "Human",
            Creature::Mythical(_) => "Mythical",
        }
    }
}

impl Creature {
    pub fn check_creature(&self) -> Option<bool> {
        match self {
            Creature::Cat(_) | Creature::Dog(_) | Creature::Human(_) => Some(true),
            _ => None,
        }
    }

    pub fn new_creature(&self) -> &Self {
        self
    }

    pub fn copy_creature(&self) -> &Self {
        Self::new_creature(&self)
    }

    pub fn creature_exists(&self) {
        match self.check_creature() {
            Some(thing) => {
                if thing == true {
                    print_type!(self);
                    println!("exists!")
                }
            }
            _ => {
                print_type!(self);
                println!("Doesn't exist")
            }
        }
    }}
