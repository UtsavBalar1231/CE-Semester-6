#[allow(dead_code)]
#[derive(Debug)]
pub struct Body {
    pub eyes: u8,
    pub nose: u8,
    pub hands: u8,
    pub legs: u8,
    pub mouth: u8,
}
#[allow(dead_code)]
#[derive(Debug)]
pub enum Creature {
    Dog(Body),
    Cat(Body),
    Human(Body),
    Mythical(Body),
    Donkey(Body),
    Monkey(Body),
    Snake(Body),
    Dragon(Body),
    Fish(Body),
    Bird(Body),
    Lizard(Body),
    Frog(Body),
    Bat(Body),
    Bear(Body),
    Elephant(Body),
    Rhino(Body),
    Giraffe(Body),    
}

use crate::get_type_str::TypeToStr;

impl TypeToStr for Creature {
     fn get_type_str(&self) -> &'static str {
        match self {
            Creature::Dog(_) => "Dog",
            Creature::Cat(_) => "Cat",
            Creature::Human(_) => "Human",
            Creature::Mythical(_) => "Mythical",
            Creature::Donkey(_) => "Donkey",
            Creature::Monkey(_) => "Monkey",
            Creature::Snake(_) => "Snake",
            Creature::Dragon(_) => "Dragon",
            Creature::Fish(_) => "Fish",
            Creature::Bird(_) => "Bird",
            Creature::Lizard(_) => "Lizard",
            Creature::Frog(_) => "Frog",
            Creature::Bat(_) => "Bat",
            Creature::Bear(_) => "Bear",
            Creature::Elephant(_) => "Elephant",
            Creature::Rhino(_) => "Rhino",
            Creature::Giraffe(_) => "Giraffe",
        }
    }
}

impl Creature {
    pub fn check_creature(&self) -> Option<bool> {
        match self {
            Creature::Cat(_) |
            Creature::Dog(_) |
            Creature::Human(_) |
            Creature::Donkey(_) |
            Creature::Monkey(_) |
            Creature::Snake(_) |
            Creature::Dragon(_) |
            Creature::Fish(_) |
            Creature::Bird(_) |
            Creature::Lizard(_) |
            Creature::Bat(_) |
            Creature::Bear(_) |
            Creature::Elephant(_) |
            Creature::Rhino(_) |
            Creature::Giraffe(_) => Some(true),
            _ => None,
        }
    }

    pub fn new_creature(&self) -> &Self {
        self
    }

    pub fn copy_creature(&self) -> &Self {
        Self::new_creature(&self)
    }

    pub fn creature_exists(&self) {
        match self.check_creature() {
            Some(thing) => {
                if thing == true {
                    println!("{:?} exists!", self.get_type_str())
                }
            }
            _ => {
                println!("{:?} Doesn't exist", self.get_type_str())
            }
        }
    }
}