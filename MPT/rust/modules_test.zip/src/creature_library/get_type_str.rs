pub trait TypeToStr {
    fn get_type_str(&self) -> &'static str;
}
