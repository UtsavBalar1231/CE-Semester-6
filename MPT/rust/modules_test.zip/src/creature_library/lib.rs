pub mod creature;
pub mod get_type_str;